<div class="footer">
    <div class="row">
        <div class="col-lg-12">
            &copy; 2014 yourdomain.com | Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a>
        </div>
    </div>
</div>
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="<?php echo e(url('assets/admin/js/jquery-1.10.2.js')); ?>"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="<?php echo e(url('assets/admin/js/bootstrap.min.js')); ?>"></script>
<!-- CUSTOM SCRIPTS -->
<script src="<?php echo e(url('assets/admin/js/custom.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\magazine\resources\views/admin/footer.blade.php ENDPATH**/ ?>