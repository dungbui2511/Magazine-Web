<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<link rel="stylesheet" href="<?php echo e(url('summernote/summernote-lite.min.css')); ?>" />
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2><?php echo e($page_tittle); ?></h2>
            </div>
            <br style="clear:both;">
            <div class="container-fluid py-6 col-lg-12" style="margin-top:60px;">
                <form method="post" enctype="multipart/form-data">
                    <?php if($errors->all()): ?>
                    <div class="alert alert-danger text-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <label for="file" class="form-label">Post tittle</label> <br>
                        <input value="<?php echo e(old('tittle')); ?>" type="text" class="form-control" placeholder="Tittle"
                            name="tittle" autofocus> <br>
                    </div>
                    <div class="mb-3">
                        <label for="file" class="form-label">Featured image</label> <br>
                        <input id="file" type="file" class="form-control" placeholder="File" name="file" id=""> <br>
                    </div>
                    <div class="mb-3">
                        <label for="category_id" class="form-label">Post category</label> <br>
                        <select name="category_id" id="" class="form-control">
                            <option>
                                --Selecte a category
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </option>
                        </select>
                    </div>
                    <?php echo csrf_field(); ?>
                    <h3>Post content</h3>
                    <textarea name="content" id="summernote" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
                    <input class="btn btn-primary" type="submit" value="Post">
                </form>
            </div>
        </div>
        <!-- /. ROW  -->
        <hr />

        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<script src="<?php echo e(url('summernote/summernote-lite.min.js')); ?>"></script>
<script>
$(document).ready(function() {
    $('#summernote').summernote();
});
</script><?php /**PATH C:\xampp\htdocs\magazine\resources\views/admin/add_post.blade.php ENDPATH**/ ?>